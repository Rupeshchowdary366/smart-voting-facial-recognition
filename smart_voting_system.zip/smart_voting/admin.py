"""
Admin Panel for Smart Voting System
Used by election officials to register voters and view results.
"""

from database import init_db, get_results
from face_recognition import FaceRecognizer
import sqlite3


def register_voter_cli():
    """CLI tool to register a new voter with face data."""
    recognizer = FaceRecognizer()

    print("\n--- VOTER REGISTRATION ---")
    voter_id = input("Enter Voter ID: ").strip().upper()
    name = input("Enter Full Name: ").strip()
    email = input("Enter Email Address: ").strip()

    # Add to database
    conn = sqlite3.connect("voting.db")
    try:
        conn.execute(
            "INSERT INTO voters (voter_id, name, email) VALUES (?, ?, ?)",
            (voter_id, name, email)
        )
        conn.commit()
        print(f"[DB] Voter {name} added to database.")
    except sqlite3.IntegrityError:
        print(f"[DB] Voter ID {voter_id} already exists.")
        conn.close()
        return
    conn.close()

    # Capture face
    print("\n[FACE] Starting face registration via webcam...")
    success = recognizer.register_from_webcam(voter_id, num_samples=20)

    if success:
        print(f"\n✅ Voter {name} ({voter_id}) registered successfully!")
    else:
        print(f"\n❌ Face registration failed for {voter_id}.")


def view_results():
    """Display current voting results."""
    results = get_results()

    print("\n" + "="*40)
    print("   VOTING RESULTS")
    print("="*40)

    if not results:
        print("  No votes cast yet.")
    else:
        total = sum(r["votes"] for r in results)
        for r in results:
            pct = (r["votes"] / total) * 100
            bar = "█" * int(pct / 5)
            print(f"  {r['voted_for']:<30} {r['votes']:>3} votes  ({pct:.1f}%)  {bar}")
        print(f"\n  Total votes cast: {total}")

    print("="*40)


def main():
    init_db()
    while True:
        print("\n--- ADMIN PANEL ---")
        print("[1] Register New Voter")
        print("[2] View Results")
        print("[3] Exit")
        choice = input("Choice: ").strip()

        if choice == "1":
            register_voter_cli()
        elif choice == "2":
            view_results()
        elif choice == "3":
            break
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
