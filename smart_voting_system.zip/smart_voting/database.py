"""
Database module for Smart Voting System
Handles voter records, vote logs, and attempt tracking using SQLite.
"""

import sqlite3
import os

DB_PATH = "voting.db"


def get_connection():
    """Return a database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initialize the database with required tables and sample voters."""
    conn = get_connection()
    cursor = conn.cursor()

    # Voters table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS voters (
            voter_id    TEXT PRIMARY KEY,
            name        TEXT NOT NULL,
            email       TEXT NOT NULL,
            has_voted   INTEGER DEFAULT 0,
            voted_for   TEXT DEFAULT NULL,
            voted_at    TEXT DEFAULT NULL
        )
    """)

    # Attempt logs table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attempt_logs (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            voter_id    TEXT NOT NULL,
            reason      TEXT NOT NULL,
            attempted_at TEXT NOT NULL
        )
    """)

    # Insert sample voters if table is empty
    cursor.execute("SELECT COUNT(*) FROM voters")
    if cursor.fetchone()[0] == 0:
        sample_voters = [
            ("AP001", "Rupesh Chowdary", "rupesh@example.com"),
            ("AP002", "Anil Kumar",      "anil@example.com"),
            ("AP003", "Priya Sharma",    "priya@example.com"),
            ("AP004", "Ravi Teja",       "ravi@example.com"),
        ]
        cursor.executemany(
            "INSERT INTO voters (voter_id, name, email) VALUES (?, ?, ?)",
            sample_voters
        )
        print("[DB] Sample voters loaded.")

    conn.commit()
    conn.close()
    print("[DB] Database initialized successfully.")


def get_voter(voter_id):
    """Fetch voter record by voter_id. Returns dict or None."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM voters WHERE voter_id = ?", (voter_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def mark_voted(voter_id, candidate, timestamp):
    """Mark a voter as having voted."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE voters
        SET has_voted = 1, voted_for = ?, voted_at = ?
        WHERE voter_id = ?
    """, (candidate, str(timestamp), voter_id))
    conn.commit()
    conn.close()


def log_attempt(voter_id, reason, timestamp):
    """Log a failed authentication attempt."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO attempt_logs (voter_id, reason, attempted_at)
        VALUES (?, ?, ?)
    """, (voter_id, reason, str(timestamp)))
    conn.commit()
    conn.close()


def get_results():
    """Return vote counts per candidate."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT voted_for, COUNT(*) as votes
        FROM voters
        WHERE has_voted = 1
        GROUP BY voted_for
        ORDER BY votes DESC
    """)
    results = cursor.fetchall()
    conn.close()
    return [dict(r) for r in results]
