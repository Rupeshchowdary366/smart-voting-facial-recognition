# Smart Voting System with Facial Recognition & OTP Verification

A secure digital voting system that uses **CNN-based facial recognition** and **OTP two-factor authentication** to ensure fraud-free elections.

Built by **Rupesh Chowdary Garlapati** | B.Tech Computer Science, VVIT 2025

---

## Features

- Real-time face detection and voter identity verification using OpenCV LBPH
- OTP sent to registered email for two-factor authentication
- SQLite database for voter records, vote logs, and attempt tracking
- Admin panel for voter registration and live result viewing
- Prevents duplicate voting — each voter can vote only once
- Logs all failed authentication attempts for audit purposes

---

## Tech Stack

| Technology | Usage |
|---|---|
| Python 3.x | Core application logic |
| OpenCV (CNN/LBPH) | Facial recognition & face detection |
| NumPy | Image array processing |
| SQLite | Voter database & vote records |
| SMTP (Gmail) | OTP email delivery |

---

## Project Structure

```
smart-voting-system/
├── app.py              # Main voting application
├── admin.py            # Admin panel (register voters, view results)
├── database.py         # Database operations
├── face_recognition.py # Face detection & verification
├── otp_service.py      # OTP generation & email delivery
├── requirements.txt    # Dependencies
└── README.md
```

---

## Setup & Installation

**1. Clone the repository**
```bash
git clone https://github.com/your-username/smart-voting-system.git
cd smart-voting-system
```

**2. Install dependencies**
```bash
pip install -r requirements.txt
```

**3. Configure email (for OTP)**

Set environment variables:
```bash
export SMTP_EMAIL="your_email@gmail.com"
export SMTP_PASSWORD="your_app_password"
```
> Use a Gmail App Password — not your main password.

**4. Register voters (Admin)**
```bash
python admin.py
```

**5. Start voting**
```bash
python app.py
```

---

## How It Works

```
Voter enters ID
      ↓
Face captured via webcam
      ↓
CNN face recognition verifies identity
      ↓
OTP sent to registered email
      ↓
Voter enters OTP
      ↓
Ballot displayed → Vote cast & recorded
```

---

## Screenshots

> *(Add screenshots of face capture window and ballot screen here)*

---

## License

This project is for educational purposes.
