"""
Face Recognition Module for Smart Voting System
Uses OpenCV's LBPH (Local Binary Pattern Histogram) face recognizer —
a lightweight CNN-inspired approach suitable for real-time verification.
"""

import cv2
import numpy as np
import os

FACE_DATA_DIR = "face_data"
MODEL_PATH = "face_model.yml"
CONFIDENCE_THRESHOLD = 70.0  # Lower = stricter matching


class FaceRecognizer:
    def __init__(self):
        self.detector = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )
        self.recognizer = cv2.face.LBPHFaceRecognizer_create()
        self.voter_index = {}  # Maps label (int) -> voter_id

        os.makedirs(FACE_DATA_DIR, exist_ok=True)

        if os.path.exists(MODEL_PATH):
            self.recognizer.read(MODEL_PATH)
            print("[FACE] Trained model loaded.")
        else:
            print("[FACE] No model found. Please register voters first.")

    def _detect_face(self, image):
        """Detect and return the largest face region from an image."""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = self.detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80))

        if len(faces) == 0:
            return None

        # Pick the largest face
        x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
        face_roi = gray[y:y+h, x:x+w]
        return cv2.resize(face_roi, (200, 200))

    def register_voter(self, voter_id, images):
        """
        Register a voter's face.
        images: list of BGR frames captured during registration.
        """
        label = abs(hash(voter_id)) % 10000
        self.voter_index[label] = voter_id

        voter_dir = os.path.join(FACE_DATA_DIR, voter_id)
        os.makedirs(voter_dir, exist_ok=True)

        faces, labels = [], []
        for i, img in enumerate(images):
            face = self._detect_face(img)
            if face is not None:
                faces.append(face)
                labels.append(label)
                path = os.path.join(voter_dir, f"{i}.jpg")
                cv2.imwrite(path, face)

        if not faces:
            print(f"[FACE] No valid faces found for voter {voter_id}.")
            return False

        self.recognizer.train(faces, np.array(labels))
        self.recognizer.save(MODEL_PATH)
        print(f"[FACE] Voter {voter_id} registered with {len(faces)} face samples.")
        return True

    def verify(self, voter_id, frame):
        """
        Verify if the captured frame matches the registered voter.
        Returns (is_match: bool, confidence: float).
        """
        face = self._detect_face(frame)
        if face is None:
            print("[FACE] No face detected in the captured image.")
            return False, 0.0

        expected_label = abs(hash(voter_id)) % 10000

        try:
            predicted_label, distance = self.recognizer.predict(face)
        except cv2.error:
            print("[FACE] Model not trained yet.")
            return False, 0.0

        # Convert distance to confidence percentage
        confidence = max(0.0, 100.0 - distance)
        is_match = (predicted_label == expected_label) and (distance < CONFIDENCE_THRESHOLD)

        return is_match, confidence

    def register_from_webcam(self, voter_id, num_samples=20):
        """Interactive registration — captures N face samples from webcam."""
        cap = cv2.VideoCapture(0)
        samples = []
        print(f"\n[FACE] Registering voter {voter_id}. Capturing {num_samples} samples...")
        print("       Look at the camera. Press Q to cancel.\n")

        while len(samples) < num_samples:
            ret, frame = cap.read()
            if not ret:
                break

            count = len(samples)
            cv2.putText(frame, f"Capturing: {count}/{num_samples}", (20, 40),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 200, 0), 2)
            cv2.imshow("Face Registration", frame)

            face = self._detect_face(frame)
            if face is not None:
                samples.append(frame)

            if cv2.waitKey(100) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

        if samples:
            return self.register_voter(voter_id, samples)
        return False
