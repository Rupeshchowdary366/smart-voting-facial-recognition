"""
OTP Service for Smart Voting System
Generates and verifies 6-digit One-Time Passwords sent via email.
"""

import random
import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta


class OTPService:
    def __init__(self, expiry_minutes=5):
        self.expiry_minutes = expiry_minutes
        self._otp_store = {}  # In production use Redis or DB

        # Email config — set these as environment variables
        self.sender_email = os.getenv("SMTP_EMAIL", "your_email@gmail.com")
        self.sender_password = os.getenv("SMTP_PASSWORD", "your_app_password")
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587

    def generate_otp(self):
        """Generate a secure 6-digit OTP."""
        otp = str(random.randint(100000, 999999))
        expiry = datetime.now() + timedelta(minutes=self.expiry_minutes)
        self._otp_store["current"] = {"otp": otp, "expiry": expiry}
        return otp

    def send_otp(self, recipient_email, otp):
        """Send OTP to voter's registered email address."""
        subject = "Your Voting OTP - Smart Voting System"
        body = f"""
Dear Voter,

Your One-Time Password (OTP) for voting verification is:

        ━━━━━━━━━━━━━━━
             {otp}
        ━━━━━━━━━━━━━━━

This OTP is valid for {self.expiry_minutes} minutes.
Do NOT share this OTP with anyone.

If you did not request this, please contact the election office immediately.

Regards,
Smart Voting System
        """

        try:
            msg = MIMEMultipart()
            msg["From"] = self.sender_email
            msg["To"] = recipient_email
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))

            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.sendmail(self.sender_email, recipient_email, msg.as_string())

            print(f"[OTP] OTP sent successfully to {recipient_email}")

        except Exception as e:
            # Fallback: print OTP to console (for demo/testing)
            print(f"[OTP] Email not configured. Demo OTP: {otp}")
            print(f"[OTP] (Email error: {e})")

    def verify_otp(self, entered_otp, expected_otp):
        """Verify the entered OTP against expected value and check expiry."""
        record = self._otp_store.get("current")

        if not record:
            print("[OTP] No OTP found. Please request a new one.")
            return False

        if datetime.now() > record["expiry"]:
            print("[OTP] OTP has expired. Please request a new one.")
            return False

        if entered_otp.strip() == expected_otp.strip():
            del self._otp_store["current"]  # Invalidate after use
            return True

        return False
