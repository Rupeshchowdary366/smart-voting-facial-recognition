"""
Smart Voting System with Facial Recognition & OTP Verification
Author: Rupesh Chowdary Garlapati
Description: A secure voting system using CNN-based facial recognition
             and OTP two-factor authentication.
"""

import cv2
import numpy as np
import random
import sqlite3
import smtplib
import os
from datetime import datetime
from email.mime.text import MIMEText
from database import init_db, get_voter, mark_voted, log_attempt
from face_recognition import FaceRecognizer
from otp_service import OTPService


def capture_face():
    """Capture face from webcam and return the image."""
    cap = cv2.VideoCapture(0)
    print("\n[INFO] Camera opened. Press SPACE to capture, Q to quit.")
    captured = None

    while True:
        ret, frame = cap.read()
        if not ret:
            print("[ERROR] Failed to access camera.")
            break

        cv2.putText(frame, "Press SPACE to capture", (20, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.imshow("Smart Voting - Face Capture", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord(' '):
            captured = frame.copy()
            print("[INFO] Face captured.")
            break
        elif key == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    return captured


def voting_menu(voter_id, voter_name):
    """Display voting ballot and get voter's choice."""
    candidates = {
        "1": "Candidate A - Party X",
        "2": "Candidate B - Party Y",
        "3": "Candidate C - Party Z",
        "4": "NOTA (None of the Above)"
    }

    print(f"\n{'='*50}")
    print(f"  Welcome, {voter_name}!")
    print(f"  Voter ID: {voter_id}")
    print(f"{'='*50}")
    print("\n  BALLOT - Please cast your vote:\n")
    for key, candidate in candidates.items():
        print(f"  [{key}] {candidate}")
    print(f"\n{'='*50}")

    while True:
        choice = input("\nEnter your choice (1-4): ").strip()
        if choice in candidates:
            confirm = input(f"\nYou selected: {candidates[choice]}\nConfirm? (yes/no): ").strip().lower()
            if confirm == "yes":
                return candidates[choice]
        else:
            print("[ERROR] Invalid choice. Please enter 1, 2, 3, or 4.")


def main():
    """Main voting flow."""
    print("\n" + "="*50)
    print("   SMART VOTING SYSTEM")
    print("   Secured by Facial Recognition & OTP")
    print("="*50)

    # Step 1 — Initialize database
    init_db()
    face_recognizer = FaceRecognizer()
    otp_service = OTPService()

    # Step 2 — Get Voter ID
    voter_id = input("\nEnter your Voter ID: ").strip().upper()
    voter = get_voter(voter_id)

    if not voter:
        print("[ERROR] Voter ID not found. Please contact the election office.")
        return

    if voter["has_voted"]:
        print("[ERROR] You have already cast your vote. Duplicate voting is not allowed.")
        return

    voter_name = voter["name"]
    voter_email = voter["email"]
    print(f"\n[INFO] Voter found: {voter_name}")

    # Step 3 — Facial Recognition
    print("\n[STEP 1/2] Facial Recognition Verification")
    print("-" * 40)
    captured_frame = capture_face()

    if captured_frame is None:
        print("[ERROR] Face capture failed. Aborting.")
        return

    is_match, confidence = face_recognizer.verify(voter_id, captured_frame)

    if not is_match:
        print(f"[FAILED] Face not recognized (confidence: {confidence:.2f}%). Access denied.")
        log_attempt(voter_id, "FACE_FAILED", datetime.now())
        return

    print(f"[SUCCESS] Face verified! (confidence: {confidence:.2f}%)")

    # Step 4 — OTP Verification
    print("\n[STEP 2/2] OTP Verification")
    print("-" * 40)
    otp = otp_service.generate_otp()
    otp_service.send_otp(voter_email, otp)
    print(f"[INFO] OTP sent to registered email: {voter_email[:3]}***@{voter_email.split('@')[1]}")

    attempts = 0
    otp_verified = False

    while attempts < 3:
        entered_otp = input("Enter OTP: ").strip()
        if otp_service.verify_otp(entered_otp, otp):
            otp_verified = True
            print("[SUCCESS] OTP verified!")
            break
        else:
            attempts += 1
            remaining = 3 - attempts
            print(f"[ERROR] Incorrect OTP. {remaining} attempt(s) remaining.")

    if not otp_verified:
        print("[FAILED] Too many incorrect OTP attempts. Access denied.")
        log_attempt(voter_id, "OTP_FAILED", datetime.now())
        return

    # Step 5 — Cast Vote
    selected_candidate = voting_menu(voter_id, voter_name)
    mark_voted(voter_id, selected_candidate, datetime.now())

    print(f"\n{'='*50}")
    print("  ✅ VOTE CAST SUCCESSFULLY!")
    print(f"  Candidate: {selected_candidate}")
    print(f"  Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Thank you for voting, {voter_name}!")
    print(f"{'='*50}\n")


if __name__ == "__main__":
    main()
